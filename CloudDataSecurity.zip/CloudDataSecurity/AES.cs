﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.Collections;

namespace CloudDataSecurity
{
    public partial class AES : Form
    {
        // Cài đặt khóa và instance vector
        // IV là một số tùy ý có thể được sử dụng cùng với khóa bí mật để mã hóa dữ liệu.
        // Là đầu vào cho 1 mật mã để thêm sự ngẫu nhiên tránh các attacker suy ra mối quan hệ giữa các đoạn tin nhắn đc mã hóa
        // Nếu bạn không có IV, thì hai tệp bắt đầu bằng văn bản giống hệt nhau sẽ tạo ra các khối đầu tiên giống hệt nhau
        // attacker sẽ biết tệp bản rõ bắt đầu bằng gì và bản mã tương ứng của nó là gì
        // =>có thể  xác định khóa và sau đó giải mã toàn bộ tệp.
        byte[] iv = new byte[16] { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 };

        

        public AES()
        {
            InitializeComponent();
            txbKey.Text = "Enter your key";
            txbMessage.Text = "Enter your message";
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            string message = txbMessage.Text;
            string key = txbKey.Text;

            // Create sha256 hash
            // Tạo hàm băm password thành 256 bit : 32 byte
            SHA256 mySHA256 = SHA256Managed.Create();
            byte[] key2 = mySHA256.ComputeHash(Encoding.ASCII.GetBytes(txbKey.Text));

            //Mã hóa và lưu ciphertext vào (encrypted)
            string encrypted = this.EncryptString2(message, key2, iv);
            //Hiện ra màn hình
            txbCiphertex.Text = encrypted;

        }
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            // Create sha256 hash
            // Tạo hàm băm password thành 256 bit : 32 byte
            SHA256 mySHA256 = SHA256Managed.Create();
            byte[] key2 = mySHA256.ComputeHash(Encoding.ASCII.GetBytes(txbKey.Text));

            // Giải mã
            string decrypted = this.DecryptString2(txbCiphertex.Text, key2, iv);
            // Hiển thị
            txbPlaintext.Text = decrypted;
        }
        private void btnSHA256_Click(object sender, EventArgs e)
        {
            txb256bit.Text = StringToBinary(txbKey.Text);

        }
        public static string StringToBinary(string data)
        {
            StringBuilder sb = new StringBuilder();

            foreach (char c in data.ToCharArray())
            {
                sb.Append(Convert.ToString(c, 2).PadLeft(8, '0'));
            }
            return sb.ToString();
        }
        public string EncryptString2(string plainText, byte[] key, byte[] iv)
        {

            // Khởi tạo một đối tượng Aes mới để thực hiện mã hóa chuỗi đối xứng 
            // Là một đối tượng cryptographic (encryptor) được sử dụng để thực hiện thuật toán đối xứng
            Aes encryptor = Aes.Create();

            // Mode để mã hóa khối là (CBC)

            //Trước khi mỗi khối văn bản thuần túy được mã hóa,
            //nó được kết hợp với văn bản mã hóa của khối trước đó bằng một phép toán OR độc quyền theo bit.
            //Điều này đảm bảo rằng ngay cả khi văn bản thuần túy chứa nhiều khối giống nhau,
            //chúng sẽ mã hóa mỗi khối thành một khối văn bản mật mã khác nhau.
            //Vectơ khởi tạo được kết hợp với khối văn bản thuần túy đầu tiên bằng phép toán OR độc quyền theo bit
            //trước khi khối được mã hóa. Nếu một bit của khối văn bản mật mã bị thay đổi, khối văn bản thuần tương ứng
            //cũng sẽ bị thay đổi. 
            encryptor.Mode = CipherMode.CBC;

            //encryptor.KeySize = 256;
            //encryptor.BlockSize = 128;
            //encryptor.Padding = PaddingMode.Zeros;

            // Cài đặt khóa và instance vector

            // IV là một số tùy ý có thể được sử dụng cùng với khóa bí mật để mã hóa dữ liệu.
            // Là đầu vào cho 1 mật mã để thêm sự ngẫu nhiên tránh các attacker suy ra mối quan hệ giữa các đoạn tin nhắn đc mã hóa
            // Nếu bạn không có IV, thì hai tệp bắt đầu bằng văn bản giống hệt nhau sẽ tạo ra các khối đầu tiên giống hệt nhau
            // attacker sẽ biết tệp bản rõ bắt đầu bằng gì và bản mã tương ứng của nó là gì
            // =>có thể  xác định khóa và sau đó giải mã toàn bộ tệp.
            encryptor.Key = key;
            encryptor.IV = iv;

            // Khởi tạo một đối tượng MemoryStream  để chứa các byte được mã hóa
            MemoryStream memoryStream = new MemoryStream();

            // Khởi tạo trình mã hóa  từ đối tượng Aes  (encryptor)
            // Tạo đối tượng mã hóa bất đối xứng        (aesEncryptor)
            ICryptoTransform aesEncryptor = encryptor.CreateEncryptor();

            // Khởi tạo một đối tượng (CryptoStream)  để xử lý dữ liệu và ghi nó vào luồng             
            // Dữ liệu đc encrypt sẽ lưu vào (memoryStream)
            CryptoStream cryptoStream = new CryptoStream(memoryStream, aesEncryptor, CryptoStreamMode.Write);

            // Chuyển chuỗi plaintext (plainText) thành một mảng byte (plainBytes)
            byte[] plainBytes = Encoding.ASCII.GetBytes(plainText);

            // Mã hóa plaintext 
            // ciphertext đc (cryptoStream) ghi vào (memoryStream)
            cryptoStream.Write(plainBytes, 0, plainBytes.Length);

            // Hoàn tất quá trình mã hóa
            //cập nhật nguồn dữ liệu cơ bản với trạng thái hiện tại của bộ đệm, sau đó xóa bộ đệm.
            cryptoStream.FlushFinalBlock();

            // Chuyển đổi dữ liệu được mã hóa từ (memoryStream) thành mảng byte
            byte[] cipherBytes = memoryStream.ToArray();

            // Đóng MemoryStream và CryptoStream
            memoryStream.Close();
            cryptoStream.Close();

            // Chuyển đổi mảng byte được mã hóa thành string    
            string cipherText = Convert.ToBase64String(cipherBytes, 0, cipherBytes.Length);

            // Trả về dữ liệu được mã hóa dưới dạng chuỗi
            return cipherText;
        }

        public string DecryptString2(string cipherText, byte[] key, byte[] iv)
        {
            // Khởi tạo một đối tượng Aes mới để thực hiện  giải mã 
            // Tạo một đối tượng cryptographic (decryptor) được sử dụng để thực hiện thuật toán đối xứng
            Aes decryptor = Aes.Create();

            decryptor.Mode = CipherMode.CBC;
            //encryptor.KeySize = 256;
            //encryptor.BlockSize = 128;
            //encryptor.Padding = PaddingMode.Zeros;

            // Cài đặt khóa và instance vector
            decryptor.Key = key;
            decryptor.IV = iv;

            // Khởi tạo một đối tượng MemoryStream  để chứa các byte được giải mã
            MemoryStream memoryStream = new MemoryStream();

            // Khởi tạo trình mã hóa  từ đối tượng Aes  (decryptor)
            // Tạo đối tượng mã hóa bất đối xứng        (aesDecryptor)
            ICryptoTransform aesDecryptor = decryptor.CreateDecryptor();

            // Khởi tạo một đối tượng (CryptoStream)  để xử lý dữ liệu và ghi nó vào luồng             
            // Dữ liệu đc encrypt sẽ lưu vào (memoryStream)      
            CryptoStream cryptoStream = new CryptoStream(memoryStream, aesDecryptor, CryptoStreamMode.Write);

            // string này sẽ chứa văn bản được giải mã (plainText)
            string plainText = String.Empty;

            try
            {
                //  Chuyển chuỗi ciphertext thành mảng byte (cipherBytes)
                byte[] cipherBytes = Convert.FromBase64String(cipherText);

                // Giải mã string ciphertext đc truyền vào
                cryptoStream.Write(cipherBytes, 0, cipherBytes.Length);

                // Hoàn thành giải mã
                cryptoStream.FlushFinalBlock();

                // Chuyển đổi dữ liệu đc giải mã đc lưu trong (memoryStream) sang mảng byte (plainBytes)
                byte[] plainBytes = memoryStream.ToArray();

                // Chuyển đổi mảng byte đó sang string
                plainText = Encoding.ASCII.GetString(plainBytes, 0, plainBytes.Length);
            }
            finally
            {
                // Đóng MemoryStream và CryptoStream
                memoryStream.Close();
                cryptoStream.Close();
            }

            // Trả về bản rõ ban đầu
            return plainText;
        }

       
    }
}
